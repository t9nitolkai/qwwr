// src/transactionManager.ts
import { Transaction, SystemProgram, sendAndConfirmTransaction, PublicKey } from '@solana/web3.js';
import { connection, wallet } from './config';
import { log } from './logger';

/**
 * Универсальная функция для повторных попыток.
 */
async function retry<T>(fn: () => Promise<T>, retries: number, delay: number): Promise<T> {
  try {
    return await fn();
  } catch (error) {
    if (retries > 0) {
      log(`Повторная попытка через ${delay} мс...`);
      await new Promise((resolve) => setTimeout(resolve, delay));
      return retry(fn, retries - 1, delay);
    } else {
      throw error;
    }
  }
}

/**
 * Отправляет транзакцию на покупку токена с повторными попытками.
 */
export async function sendBuyTransaction(amount: number, fee: number, tokenMint: PublicKey): Promise<string> {
  return retry(async () => {
    const transaction = new Transaction().add(
      SystemProgram.transfer({
        fromPubkey: wallet.publicKey,
        toPubkey: new PublicKey('RAYDIUM_POOL_ADDRESS'), // Замените на реальный адрес пула
        lamports: amount,
      })
    );

    transaction.feePayer = wallet.publicKey;
    transaction.recentBlockhash = (await connection.getRecentBlockhash()).blockhash;
    transaction.sign(wallet);

    try {
      const signature = await sendAndConfirmTransaction(connection, transaction, [wallet]);
      log(`Транзакция на покупку отправлена: ${signature}`);
      return signature;
    } catch (error: any) {
      log(`Ошибка при отправке транзакции на покупку: ${error.message}`);
      throw error;
    }
  }, 3, 1000);
}

/**
 * Отправляет транзакцию на продажу токена с повторными попытками.
 */
export async function sendSellTransaction(amount: number, fee: number, tokenMint: PublicKey): Promise<string> {
  return retry(async () => {
    const transaction = new Transaction().add(
      SystemProgram.transfer({
        fromPubkey: wallet.publicKey,
        toPubkey: new PublicKey('RAYDIUM_POOL_ADDRESS'), // Замените на реальный адрес пула
        lamports: amount,
      })
    );

    transaction.feePayer = wallet.publicKey;
    transaction.recentBlockhash = (await connection.getRecentBlockhash()).blockhash;
    transaction.sign(wallet);

    try {
      const signature = await sendAndConfirmTransaction(connection, transaction, [wallet]);
      log(`Транзакция на продажу отправлена: ${signature}`);
      return signature;
    } catch (error: any) {
      log(`Ошибка при отправке транзакции на продажу: ${error.message}`);
      throw error;
    }
  }, 3, 1000);
}

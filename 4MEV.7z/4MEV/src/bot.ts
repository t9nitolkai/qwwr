// src/bot.ts
import { getTokensToMonitor } from './tokenMonitor';
import { monitorMempoolForToken } from './mempoolMonitor';
import { WorkerPool } from './workerPool';
import { log } from './logger';

// Количество воркеров
const WORKER_COUNT = 6;
const workerPool = new WorkerPool(WORKER_COUNT);

/**
 * Основная функция бота.
 */
async function runBot() {
  try {
    const tokens = getTokensToMonitor();

    for (const token of tokens) {
      try {
        const transactions = await monitorMempoolForToken(token);

        for (const tx of transactions) {
          workerPool.addTask(tx, token.toBase58());
        }
      } catch (error: any) {
        log(`Ошибка при мониторинге токена ${token.toBase58()}: ${error.message}`);
      }
    }
  } catch (error: any) {
    log(`Ошибка в основном цикле бота: ${error.message}`);
  }
}

// Запуск бота каждые 10 секунд
setInterval(runBot, 10000);

// Завершение работы при завершении процесса
process.on('SIGINT', () => {
  workerPool.shutdown();
  process.exit();
});

// src/decisionMaker.ts
import { PublicKey, TransactionResponse } from '@solana/web3.js';
import { sendBuyTransaction, sendSellTransaction } from './transactionManager';
import { calculateAttackFee } from './feeCalculator';
import { isAttackProfitable } from './profitCalculator';
import { log } from './logger';

/**
 * Принимает решение, атаковать ли транзакцию.
 */
export async function decideAndAttack(targetTransaction: TransactionResponse, tokenMint: PublicKey) {
  try {
    const targetAmount = getTransactionAmount(targetTransaction);
    const targetFee = targetTransaction.meta?.fee || 0;

    if (!targetAmount) {
      log('Не удалось определить сумму покупки.');
      return;
    }

    const attackAmount = calculateAttackAmount(targetAmount);
    const attackFee = await calculateAttackFee(targetFee);

    // Проверяем прибыльность атаки
    if (await isAttackProfitable(targetAmount, attackAmount, targetFee, attackFee, tokenMint)) {
      log(`Атакуемая транзакция: ${targetAmount} токенов, комиссия: ${targetFee} lamports`);
      log(`Наша транзакция: ${attackAmount} токенов, комиссия: ${attackFee} lamports`);

      // Покупаем токен
      const buySignature = await sendBuyTransaction(attackAmount, attackFee, tokenMint);

      // Продаем токен
      if (buySignature) {
        const sellAmount = attackAmount; // Продаем то же количество
        const sellFee = await calculateAttackFee(targetFee); // Комиссия для продажи
        await sendSellTransaction(sellAmount, sellFee, tokenMint);
      }
    } else {
      log('Атака не выгодна, пропускаем транзакцию.');
    }
  } catch (error: any) {
    log(`Ошибка при принятии решения: ${error.message}`);
  }
}

/**
 * Извлекает сумму покупки из транзакции.
 */
function getTransactionAmount(transaction: TransactionResponse): number | null {
  // Здесь должна быть реализована логика извлечения суммы
  return 1000000; // Пример
}

/**
 * Рассчитывает сумму для покупки.
 */
function calculateAttackAmount(targetAmount: number): number {
  return targetAmount * 0.9; // Покупаем на 10% меньше
}

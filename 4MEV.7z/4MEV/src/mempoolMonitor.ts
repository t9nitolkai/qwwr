// src/mempoolMonitor.ts
import { PublicKey, TransactionResponse } from '@solana/web3.js';
import { connection } from './solanaConnection';
import { log } from './logger';

/**
 * Универсальная функция для повторных попыток.
 */
async function retry<T>(fn: () => Promise<T>, retries: number, delay: number): Promise<T> {
  try {
    return await fn();
  } catch (error) {
    if (retries > 0) {
      log(`Повторная попытка через ${delay} мс...`);
      await new Promise((resolve) => setTimeout(resolve, delay));
      return retry(fn, retries - 1, delay);
    } else {
      throw error;
    }
  }
}

/**
 * Мониторит мемпул для определенного токена с повторными попытками.
 */
export async function monitorMempoolForToken(tokenMint: PublicKey): Promise<TransactionResponse[]> {
  return retry(async () => {
    try {
      log(`Мониторинг мемпула для токена: ${tokenMint.toBase58()}`);
      const signatures = await connection.getSignaturesForAddress(tokenMint, { limit: 10 });
      const transactions: TransactionResponse[] = [];

      for (const { signature } of signatures) {
        try {
          const tx = await connection.getTransaction(signature);
          if (tx) transactions.push(tx);
        } catch (error: any) {
          log(`Ошибка при получении транзакции ${signature}: ${error.message}`);
        }
      }

      return transactions;
    } catch (error: any) {
      log(`Ошибка при мониторинге мемпула: ${error.message}`);
      throw error;
    }
  }, 3, 1000);
}

// src/solanaConnection.ts
import { Connection } from '@solana/web3.js';
import { RPC_URL, WSS_URL } from './config';

export const connection = new Connection(RPC_URL, {
  wsEndpoint: WSS_URL,
  commitment: 'confirmed',
});

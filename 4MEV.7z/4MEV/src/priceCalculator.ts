// src/priceCalculator.ts
import { PublicKey } from '@solana/web3.js';
import { getTokenPrice, getPoolLiquidity } from './grpcClient';
import { log } from './logger';

/**
 * Рассчитывает ожидаемое изменение цены токена после крупной покупки.
 */
export function calculatePriceImpact(
  targetAmount: number,  // Объем покупки атакуемой транзакции
  poolLiquidity: number  // Общая ликвидность пула
): number {
  const priceImpact = (targetAmount / poolLiquidity) * 100;
  log(`Ожидаемое изменение цены: ${priceImpact.toFixed(2)}%`);
  return priceImpact;
}

/**
 * Рассчитывает ожидаемую цену токена после изменения.
 */
export function calculateExpectedPrice(
  currentPrice: number, // Текущая цена токена
  priceImpact: number   // Ожидаемое изменение цены
): number {
  const expectedPrice = currentPrice * (1 + priceImpact / 100);
  log(`Ожидаемая цена после покупки: ${expectedPrice.toFixed(2)} lamports`);
  return expectedPrice;
}

/**
 * Получает текущую цену токена.
 */
export async function fetchTokenPrice(tokenMint: PublicKey): Promise<number> {
  return getTokenPrice(tokenMint);
}

/**
 * Получает ликвидность пула.
 */
export async function fetchPoolLiquidity(tokenMint: PublicKey): Promise<number> {
  return getPoolLiquidity(tokenMint);
}

// src/profitCalculator.ts
import { PublicKey } from '@solana/web3.js';
import { log } from './logger';
import { calculatePriceImpact, calculateExpectedPrice, fetchTokenPrice, fetchPoolLiquidity } from './priceCalculator';

/**
 * Рассчитывает прибыльность атаки с учетом изменения цены.
 */
export async function isAttackProfitable(
  targetAmount: number, // Объем покупки атакуемой транзакции
  ourAmount: number,    // Объем нашей покупки
  targetFee: number,    // Комиссия атакуемой транзакции
  ourFee: number,       // Наша комиссия
  tokenMint: PublicKey  // Адрес токена
): Promise<boolean> {
  // Получаем текущую цену токена и ликвидность пула
  const currentPrice = await fetchTokenPrice(tokenMint);
  const poolLiquidity = await fetchPoolLiquidity(tokenMint);

  // Рассчитываем изменение цены
  const priceImpact = calculatePriceImpact(targetAmount, poolLiquidity);
  const expectedPrice = calculateExpectedPrice(currentPrice, priceImpact);

  // Рассчитываем ожидаемую прибыль
  const expectedProfit = (expectedPrice - currentPrice) * ourAmount;

  // Рассчитываем общую комиссию
  const totalFee = targetFee + ourFee;

  // Прибыль должна быть больше комиссии
  const isProfitable = expectedProfit > totalFee;

  log(`Ожидаемая прибыль: ${expectedProfit.toFixed(2)} lamports, комиссия: ${totalFee.toFixed(2)} lamports`);
  log(`Атака ${isProfitable ? 'выгодна' : 'не выгодна'}`);

  return isProfitable;
}

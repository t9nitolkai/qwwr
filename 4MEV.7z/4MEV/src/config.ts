// src/config.ts
import { Keypair } from '@solana/web3.js';

// Ваши узлы
export const RPC_URL = 'https://t9nitolkai48132.ashburn.quasar.wtf/qb9c49cf-3d49-e774-9cb9-d5d6f44ec4fa';
export const WSS_URL = 'wss://t9nitolkai48132.ashburn.quasar.wtf/qb9c49cf-3d49-e774-9cb9-d5d6f44ec4fa';
export const GRPC_URL = 'https://t9nitolkai48132.ashburn.quasar.wtf:10000';
export const API_KEY = 'qb9c49cf-3d49-e774-9cb9-d5d6f44ec4fa';

// URL для получения реальных данных о мемпуле (например, через внешний API)
export const MEMPOOL_API_URL = process.env.MEMPOOL_API_URL || '';

// Ваш кошелек (вставьте приватный ключ!)
const PRIVATE_KEY = Uint8Array.from([131,111,170,191,11,146,94,107,250,138,49,168,227,237,13,12,40,228,107,106,227,244,7,23,60,85,168,183,134,181,190,48,218,7,68,109,50,42,251,178,0,252,239,215,247,165,209,80,121,65,152,156,145,53,9,8,101,170,79,69,196,97,226,244]);
export const wallet = Keypair.fromSecretKey(PRIVATE_KEY);


// src/tokenMonitor.ts
import { PublicKey } from '@solana/web3.js';
import { log } from './logger';

// Пример: список токенов для мониторинга (замените на реальные адреса)
const RAYDIUM_TOKENS: PublicKey[] = [
  new PublicKey('8sLbNZoA1cfnvMJLPfp98ZLAnFSYCFApfJKMbiXNLwxj'),
  new PublicKey('3nMFwZXwY1s1M5s8vYAHqd4wGs4iSxXE4LRoUMMYqEgF'),
];

/**
 * Возвращает список токенов для мониторинга.
 */
export function getTokensToMonitor(): PublicKey[] {
  log(`Мониторинг токенов: ${RAYDIUM_TOKENS.map(t => t.toBase58()).join(', ')}`);
  return RAYDIUM_TOKENS;
}

// src/workerPool.ts
import { Worker } from 'worker_threads';
import path from 'path';
import { log } from './logger';

interface Task {
  transaction: any;
  tokenMint: string;
}

export class WorkerPool {
  private workers: Worker[] = [];
  private freeWorkers: Worker[] = [];
  private taskQueue: Task[] = [];

  constructor(private size: number) {
    this.initWorkers();
  }

  private initWorkers() {
    for (let i = 0; i < this.size; i++) {
      const worker = new Worker(path.join(__dirname, 'decisionWorker.js'));
      worker.on('message', () => {
        this.onWorkerFree(worker);
      });
      worker.on('error', (err) => {
        log(`Ошибка в воркере: ${err.message}`);
        this.onWorkerFree(worker);
      });
      this.workers.push(worker);
      this.freeWorkers.push(worker);
    }
  }

  public addTask(transaction: any, tokenMint: string) {
    const task: Task = { transaction, tokenMint };
    if (this.freeWorkers.length > 0) {
      const worker = this.freeWorkers.shift()!;
      worker.postMessage(task);
    } else {
      this.taskQueue.push(task);
    }
  }

  private onWorkerFree(worker: Worker) {
    if (this.taskQueue.length > 0) {
      const task = this.taskQueue.shift()!;
      worker.postMessage(task);
    } else {
      this.freeWorkers.push(worker);
    }
  }

  public shutdown() {
    this.workers.forEach(worker => worker.terminate());
  }
}

// src/logger.ts
import fs from 'fs';
import path from 'path';

const LOG_FILE = path.join(__dirname, 'bot.log');

export function log(message: string) {
  const timestamp = new Date().toISOString();
  const logMessage = `[${timestamp}] ${message}\n`;
  console.log(logMessage.trim());
  fs.appendFileSync(LOG_FILE, logMessage);
}

// src/feeCalculator.ts
import { getMempoolSize } from './networkMonitor';
import { log } from './logger';

const MIN_FEE = 5000;  // Минимальная комиссия (lamports)
const MAX_FEE = 20000; // Максимальная комиссия (lamports)

/**
 * Рассчитывает комиссию для атаки.
 */
export async function calculateAttackFee(targetFee: number): Promise<number> {
  const baseFee = targetFee * 1.1; // +10%
  const mempoolSize = await getMempoolSize(); // Ждём реальные данные о размере мемпула
  
  let adjustedFee = baseFee;
  if (mempoolSize > 1000) adjustedFee *= 1.3;
  else if (mempoolSize > 500) adjustedFee *= 1.2;

  const finalFee = Math.min(Math.max(adjustedFee, MIN_FEE), MAX_FEE);
  log(`Рассчитана комиссия: ${finalFee} lamports`);
  return finalFee;
}

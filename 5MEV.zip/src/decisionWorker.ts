// src/decisionWorker.ts
import { parentPort, workerData } from 'worker_threads';
import { PublicKey } from '@solana/web3.js';
import { decideAndAttack } from './decisionMaker';

(async () => {
  const { transaction, tokenMint } = workerData;
  await decideAndAttack(transaction, new PublicKey(tokenMint));
  parentPort?.postMessage('Обработка завершена');
})();

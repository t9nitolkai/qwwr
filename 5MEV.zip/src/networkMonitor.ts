// src/networkMonitor.ts
import { log } from './logger';
import { MEMPOOL_API_URL } from './config';

/**
 * Функция для получения размера мемпула из внешнего API.
 * Если API не настроено или произошла ошибка, возвращается значение по умолчанию.
 */
export async function getMempoolSize(): Promise<number> {
  if (!MEMPOOL_API_URL) {
    log("MEMPOOL_API_URL не настроен, возвращаем значение по умолчанию: 500");
    return 500;
  }
  
  try {
    const response = await fetch(MEMPOOL_API_URL);
    if (!response.ok) {
      throw new Error(`Ошибка при получении данных: ${response.statusText}`);
    }
    const data = await response.json();
    // Предположим, что API возвращает объект вида { size: number }
    const size = data.size;
    if (typeof size !== 'number') {
      throw new Error("Некорректный формат данных от API");
    }
    log(`Получен размер мемпула: ${size}`);
    return size;
  } catch (error: any) {
    log(`Ошибка при запросе размера мемпула: ${error.message}`);
    return 500; // Возвращаем значение по умолчанию
  }
}

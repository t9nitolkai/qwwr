// src/grpcClient.ts
import * as grpc from '@grpc/grpc-js';
import * as protoLoader from '@grpc/proto-loader';
import { PublicKey } from '@solana/web3.js';
import { GRPC_URL, API_KEY } from './config';
import { log } from './logger';
import path from 'path';

// Загружаем proto-файл
const PROTO_PATH = path.join(__dirname, 'quasar.proto');
const packageDefinition = protoLoader.loadSync(PROTO_PATH, {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true,
});

const quasarProto: any = grpc.loadPackageDefinition(packageDefinition).quasar;
const client = new quasarProto.QuasarService(GRPC_URL, grpc.credentials.createInsecure());

/**
 * Универсальная функция для повторных попыток.
 */
async function retry<T>(fn: () => Promise<T>, retries: number, delay: number): Promise<T> {
  try {
    return await fn();
  } catch (error) {
    if (retries > 0) {
      log(`Повторная попытка через ${delay} мс...`);
      await new Promise((resolve) => setTimeout(resolve, delay));
      return retry(fn, retries - 1, delay);
    } else {
      throw error;
    }
  }
}

/**
 * Получает текущую цену токена через gRPC с повторными попытками.
 */
export async function getTokenPrice(tokenMint: PublicKey): Promise<number> {
  return retry(async () => {
    return new Promise((resolve, reject) => {
      const request = {
        tokenMint: tokenMint.toBase58(),
        apiKey: API_KEY,
      };

      client.getTokenPrice(request, (err: grpc.ServiceError, response: any) => {
        if (err) {
          log(`Ошибка при получении цены токена: ${err.message}`);
          reject(new Error(`Ошибка gRPC: ${err.message}`));
        } else if (!response || !response.price) {
          log('Некорректный ответ от gRPC сервера');
          reject(new Error('Некорректный ответ от gRPC сервера'));
        } else {
          log(`Текущая цена токена: ${response.price} lamports`);
          resolve(response.price);
        }
      });
    });
  }, 3, 1000);
}

/**
 * Получает ликвидность пула через gRPC с повторными попытками.
 */
export async function getPoolLiquidity(tokenMint: PublicKey): Promise<number> {
  return retry(async () => {
    return new Promise((resolve, reject) => {
      const request = {
        tokenMint: tokenMint.toBase58(),
        apiKey: API_KEY,
      };

      client.getPoolLiquidity(request, (err: grpc.ServiceError, response: any) => {
        if (err) {
          log(`Ошибка при получении ликвидности пула: ${err.message}`);
          reject(new Error(`Ошибка gRPC: ${err.message}`));
        } else if (!response || !response.liquidity) {
          log('Некорректный ответ от gRPC сервера');
          reject(new Error('Некорректный ответ от gRPC сервера'));
        } else {
          log(`Ликвидность пула: ${response.liquidity} lamports`);
          resolve(response.liquidity);
        }
      });
    });
  }, 3, 1000);
}
